<?php
session_start();
if(isset($_SESSION["tutor_id"])){ header("location:dashboard.php"); exit(); }
include "../components/connect.php";
if(isset($_POST["submit"])){
   $email = trim($_POST["email"]);
   $pass = sha1(trim($_POST["pass"]));
   $q = $conn->prepare("SELECT * FROM tutors WHERE email = ? AND password = ?");
   $q->execute([$email, $pass]);
   $row = $q->fetch(PDO::FETCH_ASSOC);
   if($q->rowCount() > 0){
      $_SESSION["tutor_id"] = $row["id"];
      header("location:dashboard.php"); exit();
   } else { $msg = "incorrect email or password!"; }
}
?>
<!DOCTYPE html><html><head>
<meta charset="UTF-8"><title>Admin Login</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
<link rel="stylesheet" href="../css/admin_style.css">
</head><body>
<section class="form-container">
<form action="" method="post" class="login">
<h3>admin login</h3>
<?php if(isset($msg)) echo "<div class=message><span>".$msg."</span></div>"; ?>
<p>your email <span>*</span></p>
<input type="email" name="email" placeholder="enter your email" maxlength="50" required class="box">
<p>your password <span>*</span></p>
<input type="password" name="pass" placeholder="enter your password" maxlength="20" required class="box">
<input type="submit" name="submit" value="login now" class="btn">
</form></section>
<script src="../js/admin_script.js"></script>
</body></html>