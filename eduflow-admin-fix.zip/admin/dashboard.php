<?php
session_start();
if(isset($_SESSION["tutor_id"])){
   $tutor_id = $_SESSION["tutor_id"];
} elseif(isset($_COOKIE["tutor_id"])){
   $tutor_id = $_COOKIE["tutor_id"];
   $_SESSION["tutor_id"] = $tutor_id;
} else {
   header("location:login.php"); exit();
}
include "../components/connect.php";
$p = $conn->prepare("SELECT * FROM tutors WHERE id = ?");
$p->execute([$tutor_id]);
$fetch_profile = $p->fetch(PDO::FETCH_ASSOC);
$c = $conn->prepare("SELECT * FROM content WHERE tutor_id = ?");
$c->execute([$tutor_id]); $total_contents = $c->rowCount();
$pl = $conn->prepare("SELECT * FROM playlist WHERE tutor_id = ?");
$pl->execute([$tutor_id]); $total_playlists = $pl->rowCount();
$l = $conn->prepare("SELECT * FROM likes WHERE tutor_id = ?");
$l->execute([$tutor_id]); $total_likes = $l->rowCount();
$cm = $conn->prepare("SELECT * FROM comments WHERE tutor_id = ?");
$cm->execute([$tutor_id]); $total_comments = $cm->rowCount();
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
<link rel="stylesheet" href="../css/admin_style.css">
</head><body>
<?php include "../components/admin_header.php"; ?>
<section class="dashboard">
<h1 class="heading">dashboard</h1>
<div class="box-container">
<div class="box"><h3>welcome!</h3><p><?= $fetch_profile["name"]; ?></p><a href="profile.php" class="btn">view profile</a></div>
<div class="box"><h3><?= $total_contents; ?></h3><p>total contents</p><a href="add_content.php" class="btn">add new content</a></div>
<div class="box"><h3><?= $total_playlists; ?></h3><p>total playlists</p><a href="add_playlist.php" class="btn">add new playlist</a></div>
<div class="box"><h3><?= $total_likes; ?></h3><p>total likes</p><a href="contents.php" class="btn">view contents</a></div>
<div class="box"><h3><?= $total_comments; ?></h3><p>total comments</p><a href="comments.php" class="btn">view comments</a></div>
<div class="box"><h3>quick select</h3><p>login or register</p>
<div class="flex-btn"><a href="login.php" class="option-btn">login</a><a href="register.php" class="option-btn">register</a></div></div>
</div></section>
<?php include "../components/footer.php"; ?>
<script src="../js/admin_script.js"></script>
</body></html>