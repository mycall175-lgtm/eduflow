<?php
// =============================================
// EduFlow LMS – Configuration
// =============================================
// EDIT THESE VALUES to match your Namecheap MySQL details

define('DB_HOST', 'localhost');
define('DB_NAME', 'eduflow_db');   // your database name
define('DB_USER', 'root');         // your MySQL username
define('DB_PASS', '');             // your MySQL password
define('DB_CHARSET', 'utf8mb4');

define('SITE_URL', 'http://localhost/eduflow-php'); // change to your domain
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');

// Session settings
ini_set('session.cookie_lifetime', 60 * 60 * 24 * 30); // 30 days
ini_set('session.gc_maxlifetime', 60 * 60 * 24 * 30);

session_start();

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
