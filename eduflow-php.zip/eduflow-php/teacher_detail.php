<?php require_once 'config.php';
$id = $_GET['id'] ?? '';
$tutor = $id ? getTutor($id) : null;
if (!$tutor) { header('Location: teachers.php'); exit; }
$tutorPlaylists = getTutorPlaylists($id);
$pageTitle = $tutor['name'];
include 'includes/header.php'; ?>

<section class="course-detail-hero">
  <div class="container">
    <div class="breadcrumb">
      <a href="teachers.php">Teachers</a>
      <span>›</span>
      <span><?= h($tutor['name']) ?></span>
    </div>
    <div style="display:flex;align-items:flex-start;gap:2rem;flex-wrap:wrap">
      <div class="avatar avatar-lg"><?= strtoupper(substr($tutor['name'], 0, 1)) ?></div>
      <div style="flex:1">
        <h1 style="font-size:1.75rem;font-weight:700"><?= h($tutor['name']) ?></h1>
        <p class="text-muted"><?= h($tutor['profession']) ?></p>
        <?php if ($tutor['profile']): ?>
          <p style="margin-top:1rem;line-height:1.7;max-width:600px"><?= nl2br(h($tutor['profile'])) ?></p>
        <?php endif; ?>
        <div style="margin-top:.75rem">
          <span class="badge badge-primary">&#128218; <?= count($tutorPlaylists) ?> Course<?= count($tutorPlaylists) !== 1 ? 's' : '' ?></span>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 style="font-size:1.25rem;font-weight:700;margin-bottom:1.5rem">Courses by <?= h($tutor['name']) ?></h2>
    <?php if ($tutorPlaylists): ?>
      <div class="courses-grid">
        <?php foreach ($tutorPlaylists as $pl): ?>
          <a href="course_detail.php?id=<?= h($pl['id']) ?>" class="course-card">
            <div class="course-thumb">
              <img src="<?= getThumbnailUrl($pl['thumbnail'], $pl['title']) ?>" alt="<?= h($pl['title']) ?>" loading="lazy">
              <span class="course-category"><?= h($pl['category']) ?></span>
            </div>
            <div class="course-body">
              <div class="course-title"><?= h($pl['title']) ?></div>
              <div class="course-meta">
                <span class="course-tutor">&#127891; <?= h($tutor['name']) ?></span>
                <span class="course-videos">&#127909; <?= (int)$pl['video_count'] ?> videos</span>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state"><div class="icon">&#128218;</div><h3>No courses yet</h3></div>
    <?php endif; ?>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
