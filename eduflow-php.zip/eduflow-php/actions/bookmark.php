<?php require_once '../config.php';

$isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) || !isset($_POST['redirect']);
if ($isAjax) header('Content-Type: application/json');

if (!isStudent()) {
    if ($isAjax) { echo json_encode(['success' => false, 'redirect' => SITE_URL . '/login.php']); exit; }
    header('Location: ' . SITE_URL . '/login.php'); exit;
}

$playlist_id = $_POST['playlist_id'] ?? '';
$redirect = $_POST['redirect'] ?? 'bookmarks.php';

if (!$playlist_id) {
    if ($isAjax) { echo json_encode(['success' => false]); exit; }
    header('Location: ' . SITE_URL . '/' . $redirect); exit;
}

$db = getDB();
$userId = $_SESSION['user_id'];
$check = $db->prepare("SELECT id FROM bookmarks WHERE playlist_id = ? AND user_id = ?");
$check->execute([$playlist_id, $userId]);
$existing = $check->fetch();

if ($existing) {
    $db->prepare("DELETE FROM bookmarks WHERE playlist_id = ? AND user_id = ?")->execute([$playlist_id, $userId]);
    $bookmarked = false;
} else {
    $db->prepare("INSERT INTO bookmarks (id, playlist_id, user_id) VALUES (?, ?, ?)")->execute([uid(), $playlist_id, $userId]);
    $bookmarked = true;
}

if ($isAjax) {
    echo json_encode(['success' => true, 'bookmarked' => $bookmarked]);
} else {
    flash('success', $bookmarked ? 'Course bookmarked!' : 'Bookmark removed.');
    header('Location: ' . SITE_URL . '/' . $redirect); exit;
}
