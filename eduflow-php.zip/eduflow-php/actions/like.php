<?php require_once '../config.php';
header('Content-Type: application/json');

if (!isStudent()) {
    echo json_encode(['success' => false, 'redirect' => SITE_URL . '/login.php']);
    exit;
}

$content_id = $_POST['content_id'] ?? '';
if (!$content_id) { echo json_encode(['success' => false]); exit; }

$db = getDB();
$userId = $_SESSION['user_id'];

$check = $db->prepare("SELECT id FROM likes WHERE content_id = ? AND user_id = ?");
$check->execute([$content_id, $userId]);
$existing = $check->fetch();

if ($existing) {
    $db->prepare("DELETE FROM likes WHERE content_id = ? AND user_id = ?")->execute([$content_id, $userId]);
    $liked = false;
} else {
    $db->prepare("INSERT INTO likes (id, content_id, user_id) VALUES (?, ?, ?)")->execute([uid(), $content_id, $userId]);
    $liked = true;
}

$count = (int)$db->prepare("SELECT COUNT(*) FROM likes WHERE content_id = ?")->execute([$content_id]) ? 0 : 0;
$stmt = $db->prepare("SELECT COUNT(*) FROM likes WHERE content_id = ?");
$stmt->execute([$content_id]);
$count = (int)$stmt->fetchColumn();

echo json_encode(['success' => true, 'liked' => $liked, 'count' => $count]);
