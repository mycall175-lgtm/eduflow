<?php require_once '../config.php';
requireStudent();
$content_id = $_POST['content_id'] ?? '';
$comment = trim($_POST['comment'] ?? '');
$redirect = $_POST['redirect'] ?? 'index.php';

if ($content_id && $comment) {
    $db = getDB();
    $db->prepare("INSERT INTO comments (id, content_id, user_id, comment) VALUES (?, ?, ?, ?)")
       ->execute([uid(), $content_id, $_SESSION['user_id'], $comment]);
    flash('success', 'Comment added!');
}
header('Location: ' . SITE_URL . '/' . $redirect);
exit;
