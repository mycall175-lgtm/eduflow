<?php require_once 'config.php';
$pageTitle = 'About';
include 'includes/header.php'; ?>

<section class="hero" style="padding:4rem 0">
  <div class="container">
    <h1>About <span class="text-primary">EduFlow</span></h1>
    <p>EduFlow emerged from the need to address "educational fragmentation" in the digital era — bringing video courses, student interaction, and tutor management into one clean, professional platform.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="about-mission">
      <div>
        <h2 style="font-size:1.75rem;font-weight:700;margin-bottom:1rem">Our Mission</h2>
        <p class="text-muted" style="line-height:1.8;margin-bottom:1rem">EduFlow is a role-based Learning Management System designed to give independent tutors and students a centralized, professional learning environment. Instead of juggling WhatsApp groups, Google Drive folders, and YouTube links, everything lives in one place.</p>
        <p class="text-muted" style="line-height:1.8;margin-bottom:1.5rem">Tutors get a powerful admin dashboard to manage courses, upload videos, and moderate discussions. Students get a clean, distraction-free portal to browse, watch, comment, and bookmark their favourite courses.</p>
        <a href="courses.php" class="btn btn-primary">Browse Courses</a>
        <a href="register.php" class="btn btn-outline" style="margin-left:.75rem">Get Started Free</a>
      </div>
      <div class="about-features" style="grid-template-columns:1fr 1fr">
        <div class="feature-item">
          <div class="feature-icon">&#128218;</div>
          <h3>Structured Playlists</h3>
          <p>Courses organized into clear playlists with individual video lessons.</p>
        </div>
        <div class="feature-item">
          <div class="feature-icon">&#128101;</div>
          <h3>Role-Based Access</h3>
          <p>Separate portals for students and tutors with appropriate permissions.</p>
        </div>
        <div class="feature-item">
          <div class="feature-icon">&#128241;</div>
          <h3>Mobile-First Design</h3>
          <p>CSS Grid responsive layout that works on any screen size.</p>
        </div>
        <div class="feature-item">
          <div class="feature-icon">&#9790;</div>
          <h3>Dark Mode</h3>
          <p>Persistent theme preference saved to LocalStorage across all sessions.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section section-alt">
  <div class="container">
    <div class="section-header" style="justify-content:center;text-align:center;display:block;margin-bottom:2.5rem">
      <h2>Key Features</h2>
      <p class="text-muted mt-1">Everything you need for professional online learning</p>
    </div>
    <div class="about-features">
      <?php $features = [
        ['&#127909;','YouTube-Style Player','Responsive 16:9 video player with YouTube embedding. Works on all devices without distortion.'],
        ['&#128218;','Course Playlists','Tutors create structured playlists and organize video lessons in clear sequential order.'],
        ['&#128172;','Community Interaction','Students like videos, leave comments, and bookmark full playlists to their personal library.'],
        ['&#128274;','Secure &amp; Protected','Session-based auth with hashed passwords. Role-based access protects tutor and student areas.'],
        ['&#128241;','Fully Responsive','Built mobile-first using CSS Grid and Flexbox. Perfect on a 5-inch phone or 24-inch monitor.'],
        ['&#9790;','Persistent Dark Mode','Toggle light and dark mode. Your preference is remembered with LocalStorage across sessions.'],
      ];
      foreach ($features as [$icon, $title, $desc]): ?>
        <div class="feature-item">
          <div class="feature-icon"><?= $icon ?></div>
          <h3><?= $title ?></h3>
          <p><?= $desc ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="cta-banner">
  <div class="container">
    <h2>Ready to Start Learning?</h2>
    <p>Join EduFlow today — it's free for students. Browse expert-led video courses and learn at your own pace.</p>
    <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap">
      <a href="register.php" class="btn btn-lg" style="background:#fff;color:var(--primary)">Create Free Account</a>
      <a href="courses.php" class="btn btn-outline btn-lg" style="border-color:rgba(255,255,255,.4);color:#fff">Browse Courses</a>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
