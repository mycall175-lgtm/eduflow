</div><!-- .admin-main -->
</div><!-- .admin-wrap -->
<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>document.getElementById('sidebar-toggle')&&(document.getElementById('sidebar-toggle').style.display='inline-flex');</script>
</body>
</html>
