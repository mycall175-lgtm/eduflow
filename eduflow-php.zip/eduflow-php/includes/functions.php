<?php
function uid($len = 20) {
    return substr(bin2hex(random_bytes($len)), 0, $len);
}

function isStudent() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isTutor() {
    return isset($_SESSION['tutor_id']) && !empty($_SESSION['tutor_id']);
}

function requireStudent() {
    if (!isStudent()) { header('Location: ' . SITE_URL . '/login.php'); exit; }
}

function requireTutor() {
    if (!isTutor()) { header('Location: ' . SITE_URL . '/admin/login.php'); exit; }
}

function h($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

function getYouTubeEmbed($url) {
    if (empty($url)) return '';
    $pattern = '/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i';
    if (preg_match($pattern, $url, $m)) {
        return 'https://www.youtube.com/embed/' . $m[1];
    }
    return '';
}

function isYouTube($url) {
    return strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false;
}

function getPlaylists($search = '', $category = '') {
    $db = getDB();
    $sql = "SELECT p.*, t.name AS tutor_name, t.profession AS tutor_profession,
                   (SELECT COUNT(*) FROM content c WHERE c.playlist_id = p.id AND c.status='active') AS video_count
            FROM playlists p
            JOIN tutors t ON t.id = p.tutor_id
            WHERE p.status = 'active'";
    $params = [];
    if ($search) { $sql .= " AND (p.title LIKE ? OR p.description LIKE ? OR t.name LIKE ?)"; $params = array_merge($params, ["%$search%", "%$search%", "%$search%"]); }
    if ($category) { $sql .= " AND p.category = ?"; $params[] = $category; }
    $sql .= " ORDER BY p.created_at DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getPlaylist($id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT p.*, t.name AS tutor_name, t.profession AS tutor_profession, t.profile AS tutor_profile, t.image AS tutor_image FROM playlists p JOIN tutors t ON t.id = p.tutor_id WHERE p.id = ? AND p.status='active'");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function getPlaylistVideos($playlist_id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM content WHERE playlist_id = ? AND status='active' ORDER BY created_at ASC");
    $stmt->execute([$playlist_id]);
    return $stmt->fetchAll();
}

function getVideo($id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT c.*, p.title AS playlist_title, t.name AS tutor_name, t.image AS tutor_image, t.profession AS tutor_profession FROM content c JOIN playlists p ON p.id = c.playlist_id JOIN tutors t ON t.id = c.tutor_id WHERE c.id = ? AND c.status='active'");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function getLikeCount($content_id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT COUNT(*) FROM likes WHERE content_id = ?");
    $stmt->execute([$content_id]);
    return (int)$stmt->fetchColumn();
}

function hasLiked($content_id, $user_id) {
    if (!$user_id) return false;
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM likes WHERE content_id = ? AND user_id = ?");
    $stmt->execute([$content_id, $user_id]);
    return (bool)$stmt->fetch();
}

function hasBookmarked($playlist_id, $user_id) {
    if (!$user_id) return false;
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM bookmarks WHERE playlist_id = ? AND user_id = ?");
    $stmt->execute([$playlist_id, $user_id]);
    return (bool)$stmt->fetch();
}

function getComments($content_id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT cm.*, u.name AS user_name FROM comments cm JOIN users u ON u.id = cm.user_id WHERE cm.content_id = ? ORDER BY cm.created_at DESC");
    $stmt->execute([$content_id]);
    return $stmt->fetchAll();
}

function getTutors() {
    $db = getDB();
    $stmt = $db->prepare("SELECT t.*, (SELECT COUNT(*) FROM playlists p WHERE p.tutor_id = t.id AND p.status='active') AS playlist_count FROM tutors t ORDER BY t.created_at ASC");
    $stmt->execute();
    return $stmt->fetchAll();
}

function getTutor($id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM tutors WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function getTutorPlaylists($tutor_id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT p.*, (SELECT COUNT(*) FROM content c WHERE c.playlist_id = p.id AND c.status='active') AS video_count FROM playlists p WHERE p.tutor_id = ? AND p.status='active' ORDER BY p.created_at DESC");
    $stmt->execute([$tutor_id]);
    return $stmt->fetchAll();
}

function getCategories() {
    $db = getDB();
    $stmt = $db->query("SELECT DISTINCT category FROM playlists WHERE status='active' ORDER BY category");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

function handleUpload($field, $subdir = '') {
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return '';
    $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
    if (!in_array($_FILES[$field]['type'], $allowed)) return '';
    $ext = pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION);
    $filename = uid(20) . '.' . strtolower($ext);
    $dir = UPLOAD_DIR . ($subdir ? $subdir . '/' : '');
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    move_uploaded_file($_FILES[$field]['tmp_name'], $dir . $filename);
    return ($subdir ? $subdir . '/' : '') . $filename;
}

function timeAgo($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);
    if ($diff->y > 0) return $diff->y . ' year' . ($diff->y > 1 ? 's' : '') . ' ago';
    if ($diff->m > 0) return $diff->m . ' month' . ($diff->m > 1 ? 's' : '') . ' ago';
    if ($diff->d > 0) return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
    if ($diff->h > 0) return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
    if ($diff->i > 0) return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';
    return 'just now';
}

function flash($key, $msg = null) {
    if ($msg !== null) { $_SESSION['flash'][$key] = $msg; return; }
    if (isset($_SESSION['flash'][$key])) { $m = $_SESSION['flash'][$key]; unset($_SESSION['flash'][$key]); return $m; }
    return null;
}

function getThumbnailUrl($thumb, $title = 'Course') {
    if ($thumb && file_exists(UPLOAD_DIR . $thumb)) {
        return UPLOAD_URL . h($thumb);
    }
    // Generate gradient placeholder
    $colors = ['0e929e','7c3aed','dc2626','d97706','16a34a','2563eb'];
    $color = $colors[crc32($title) % count($colors)];
    return "https://via.placeholder.com/400x225/{$color}/ffffff?text=" . urlencode(substr($title, 0, 20));
}
