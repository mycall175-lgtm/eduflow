<?php
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            die('<div style="font-family:sans-serif;padding:40px;color:#c00;background:#fff0f0;border:1px solid #c00;border-radius:8px;margin:40px auto;max-width:600px"><h2>Database Connection Error</h2><p>Could not connect to MySQL. Please check your <code>config.php</code> settings.</p><p><small>' . htmlspecialchars($e->getMessage()) . '</small></p></div>');
        }
    }
    return $pdo;
}
