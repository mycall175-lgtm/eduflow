<?php
$adminPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? h($pageTitle) . ' — EduFlow Admin' : 'EduFlow Admin' ?></title>
  <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
  <script>(function(){var t=localStorage.getItem('eduflow-theme');if(t==='dark'||((!t)&&window.matchMedia('(prefers-color-scheme:dark)').matches))document.documentElement.classList.add('dark');})();</script>
</head>
<body>

<div class="admin-wrap">
<aside class="admin-sidebar" id="admin-sidebar">
  <div class="admin-logo">
    <div class="logo-icon">EF</div>
    <span>EduFlow</span>
  </div>

  <nav class="admin-nav">
    <div class="admin-nav-section">Main</div>
    <a href="<?= SITE_URL ?>/admin/dashboard.php" <?= $adminPage==='dashboard'?'class="active"':'' ?>>
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
      Dashboard
    </a>

    <div class="admin-nav-section">Courses</div>
    <a href="<?= SITE_URL ?>/admin/add_playlist.php" <?= $adminPage==='add_playlist'?'class="active"':'' ?>>
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
      Add Playlist
    </a>
    <a href="<?= SITE_URL ?>/admin/view_playlists.php" <?= $adminPage==='view_playlists'?'class="active"':'' ?>>
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
      Playlists
    </a>

    <div class="admin-nav-section">Videos</div>
    <a href="<?= SITE_URL ?>/admin/add_content.php" <?= $adminPage==='add_content'?'class="active"':'' ?>>
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.678v6.644a1 1 0 01-1.447.894L15 14M3 8a2 2 0 012-2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z"/></svg>
      Add Content
    </a>
    <a href="<?= SITE_URL ?>/admin/view_contents.php" <?= $adminPage==='view_contents'?'class="active"':'' ?>>
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
      Contents
    </a>

    <div class="admin-nav-section">Community</div>
    <a href="<?= SITE_URL ?>/admin/view_comments.php" <?= $adminPage==='view_comments'?'class="active"':'' ?>>
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
      Comments
    </a>

    <div class="admin-nav-section">Account</div>
    <a href="<?= SITE_URL ?>/admin/profile.php" <?= $adminPage==='profile'?'class="active"':'' ?>>
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
      Profile
    </a>
    <a href="<?= SITE_URL ?>/admin/logout.php" style="color:var(--danger)">
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
      Log out
    </a>
  </nav>

  <div style="padding:1rem 1.25rem;border-top:1px solid var(--border);font-size:.78rem;color:var(--text3)">
    Logged in as<br><strong style="color:var(--text)"><?= h($_SESSION['tutor_name'] ?? '') ?></strong>
  </div>
</aside>

<div class="admin-main">
  <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:1.5rem;padding-bottom:1rem;border-bottom:1px solid var(--border)">
    <button onclick="toggleAdminSidebar()" class="btn btn-ghost btn-sm" style="display:none" id="sidebar-toggle">&#9776;</button>
    <div style="flex:1">
      <?php
      $fs = flash('success'); $fe = flash('error');
      if ($fs) echo '<div class="alert alert-success">' . h($fs) . '</div>';
      if ($fe) echo '<div class="alert alert-error">' . h($fe) . '</div>';
      ?>
    </div>
    <button class="theme-btn" onclick="toggleTheme()">&#9790;</button>
    <a href="<?= SITE_URL ?>/" class="btn btn-ghost btn-sm" target="_blank">&#127968; View Site</a>
  </div>
