<?php
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$isDark = ''; // handled by JS
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? h($pageTitle) . ' — EduFlow' : 'EduFlow LMS' ?></title>
  <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
  <script>
    // Apply dark mode before paint
    (function(){var t=localStorage.getItem('eduflow-theme');if(t==='dark'||((!t)&&window.matchMedia('(prefers-color-scheme:dark)').matches))document.documentElement.classList.add('dark');})();
  </script>
</head>
<body>

<nav class="navbar">
  <div class="container">
    <div class="nav-inner">
      <a href="<?= SITE_URL ?>/" class="nav-logo">
        <div class="logo-icon">EF</div>
        <span>EduFlow</span>
      </a>

      <div class="nav-links">
        <a href="<?= SITE_URL ?>/" <?= $currentPage === 'index' ? 'class="active"' : '' ?>>Home</a>
        <a href="<?= SITE_URL ?>/courses.php" <?= $currentPage === 'courses' ? 'class="active"' : '' ?>>Courses</a>
        <a href="<?= SITE_URL ?>/teachers.php" <?= $currentPage === 'teachers' ? 'class="active"' : '' ?>>Teachers</a>
        <a href="<?= SITE_URL ?>/about.php" <?= $currentPage === 'about' ? 'class="active"' : '' ?>>About</a>
        <a href="<?= SITE_URL ?>/contact.php" <?= $currentPage === 'contact' ? 'class="active"' : '' ?>>Contact</a>
      </div>

      <div class="nav-actions">
        <a href="<?= SITE_URL ?>/search.php" class="nav-search-btn" title="Search">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        </a>
        <button class="theme-btn" onclick="toggleTheme()" title="Toggle dark mode">&#9790;</button>

        <?php if (isStudent()): ?>
          <div class="user-menu">
            <button class="user-avatar" data-dropdown="user-dropdown" title="<?= h($_SESSION['user_name']) ?>">
              <?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?>
            </button>
            <div class="dropdown-menu" id="user-dropdown">
              <div style="padding:.5rem 1rem .4rem;border-bottom:1px solid var(--border)">
                <div style="font-weight:600;font-size:.85rem"><?= h($_SESSION['user_name']) ?></div>
                <div style="font-size:.75rem;color:var(--text3)"><?= h($_SESSION['user_email']) ?></div>
              </div>
              <a href="<?= SITE_URL ?>/bookmarks.php" class="dropdown-item">&#128278; My Bookmarks</a>
              <div class="dropdown-divider"></div>
              <a href="<?= SITE_URL ?>/logout.php" class="dropdown-item danger">&#10006; Log out</a>
            </div>
          </div>
        <?php else: ?>
          <a href="<?= SITE_URL ?>/login.php" class="btn btn-ghost btn-sm">Log in</a>
          <a href="<?= SITE_URL ?>/register.php" class="btn btn-primary btn-sm">Sign up</a>
          <a href="<?= SITE_URL ?>/admin/login.php" class="btn btn-outline btn-sm" style="display:none" id="tutor-btn">Become a Tutor</a>
        <?php endif; ?>

        <a href="<?= SITE_URL ?>/admin/login.php" class="btn btn-outline btn-sm" id="tutor-link">Become a Tutor</a>

        <button class="hamburger" onclick="toggleMobileNav()" aria-label="Menu">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>

    <div class="mobile-nav" id="mobile-nav">
      <a href="<?= SITE_URL ?>/" <?= $currentPage === 'index' ? 'class="active"' : '' ?>>&#127968; Home</a>
      <a href="<?= SITE_URL ?>/courses.php" <?= $currentPage === 'courses' ? 'class="active"' : '' ?>>&#128218; Courses</a>
      <a href="<?= SITE_URL ?>/teachers.php" <?= $currentPage === 'teachers' ? 'class="active"' : '' ?>>&#127979; Teachers</a>
      <a href="<?= SITE_URL ?>/about.php" <?= $currentPage === 'about' ? 'class="active"' : '' ?>>&#8505; About</a>
      <a href="<?= SITE_URL ?>/contact.php" <?= $currentPage === 'contact' ? 'class="active"' : '' ?>>&#9993; Contact</a>
      <a href="<?= SITE_URL ?>/search.php">&#128269; Search</a>
      <a href="<?= SITE_URL ?>/admin/login.php" style="color:var(--primary);font-weight:600">&#127891; Become a Tutor</a>
      <?php if (isStudent()): ?>
        <a href="<?= SITE_URL ?>/bookmarks.php">&#128278; Bookmarks</a>
        <a href="<?= SITE_URL ?>/logout.php" style="color:var(--danger)">&#10006; Log out</a>
      <?php else: ?>
        <a href="<?= SITE_URL ?>/login.php">&#128274; Log in</a>
        <a href="<?= SITE_URL ?>/register.php">&#128100; Sign up</a>
      <?php endif; ?>
    </div>
  </div>
</nav>

<main>
<?php
// Show flash messages
$flash_s = flash('success');
$flash_e = flash('error');
if ($flash_s) echo '<div class="container mt-2"><div class="alert alert-success">' . h($flash_s) . '</div></div>';
if ($flash_e) echo '<div class="container mt-2"><div class="alert alert-error">' . h($flash_e) . '</div></div>';
?>
