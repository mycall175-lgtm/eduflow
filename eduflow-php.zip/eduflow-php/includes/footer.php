</main>

<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <a href="<?= SITE_URL ?>/" class="nav-logo" style="margin-bottom:.75rem">
          <div class="logo-icon">EF</div>
          <span>EduFlow</span>
        </a>
        <p>A professional learning management system connecting students with expert tutors worldwide.</p>
      </div>
      <div class="footer-col">
        <h4>Platform</h4>
        <ul>
          <li><a href="<?= SITE_URL ?>/courses.php">Browse Courses</a></li>
          <li><a href="<?= SITE_URL ?>/teachers.php">Our Teachers</a></li>
          <li><a href="<?= SITE_URL ?>/search.php">Search</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Company</h4>
        <ul>
          <li><a href="<?= SITE_URL ?>/about.php">About Us</a></li>
          <li><a href="<?= SITE_URL ?>/contact.php">Contact</a></li>
          <li><a href="<?= SITE_URL ?>/admin/login.php" style="color:var(--primary)">Become a Tutor</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Account</h4>
        <ul>
          <li><a href="<?= SITE_URL ?>/login.php">Log in</a></li>
          <li><a href="<?= SITE_URL ?>/register.php">Sign up</a></li>
          <li><a href="<?= SITE_URL ?>/bookmarks.php">My Bookmarks</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?= date('Y') ?> EduFlow LMS. All rights reserved.</span>
      <span>Built with PHP &amp; MySQL</span>
    </div>
  </div>
</footer>

<script src="<?= SITE_URL ?>/js/main.js"></script>
</body>
</html>
