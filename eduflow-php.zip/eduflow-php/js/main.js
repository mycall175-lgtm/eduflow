// =============================================
// EduFlow LMS – Main JavaScript
// =============================================

// ---------- Dark Mode ----------
(function () {
  const html = document.documentElement;
  const saved = localStorage.getItem('eduflow-theme');
  if (saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    html.classList.add('dark');
  }
})();

function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.classList.toggle('dark');
  localStorage.setItem('eduflow-theme', isDark ? 'dark' : 'light');
  updateThemeIcon(isDark);
}

function updateThemeIcon(isDark) {
  const btn = document.querySelector('.theme-btn');
  if (btn) btn.innerHTML = isDark ? '&#9728;' : '&#9790;';
}

// ---------- Dropdowns ----------
document.addEventListener('click', function (e) {
  const trigger = e.target.closest('[data-dropdown]');
  const allMenus = document.querySelectorAll('.dropdown-menu');

  if (trigger) {
    const menuId = trigger.getAttribute('data-dropdown');
    const menu = document.getElementById(menuId);
    const isOpen = menu && menu.classList.contains('show');
    allMenus.forEach(m => m.classList.remove('show'));
    if (!isOpen && menu) menu.classList.add('show');
    e.stopPropagation();
    return;
  }
  allMenus.forEach(m => m.classList.remove('show'));
});

// ---------- Mobile Nav ----------
function toggleMobileNav() {
  const nav = document.getElementById('mobile-nav');
  if (nav) nav.classList.toggle('show');
}

// ---------- Admin Sidebar Toggle ----------
function toggleAdminSidebar() {
  const sb = document.querySelector('.admin-sidebar');
  if (sb) sb.classList.toggle('show');
}

// ---------- Like Button (AJAX) ----------
function toggleLike(btn, contentId) {
  fetch('<?php echo SITE_URL ?? ""; ?>/actions/like.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'content_id=' + encodeURIComponent(contentId)
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      btn.classList.toggle('liked', data.liked);
      const span = btn.querySelector('.like-count');
      if (span) span.textContent = data.count;
    } else if (data.redirect) {
      window.location.href = data.redirect;
    }
  });
}

// ---------- Bookmark Button (AJAX) ----------
function toggleBookmark(btn, playlistId) {
  fetch('<?php echo SITE_URL ?? ""; ?>/actions/bookmark.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'playlist_id=' + encodeURIComponent(playlistId)
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      btn.classList.toggle('bookmarked', data.bookmarked);
      const span = btn.querySelector('.bm-label');
      if (span) span.textContent = data.bookmarked ? 'Bookmarked' : 'Bookmark';
    } else if (data.redirect) {
      window.location.href = data.redirect;
    }
  });
}

// ---------- Init ----------
document.addEventListener('DOMContentLoaded', function () {
  const isDark = document.documentElement.classList.contains('dark');
  updateThemeIcon(isDark);

  // Auto-dismiss flash messages
  setTimeout(() => {
    document.querySelectorAll('.alert').forEach(a => {
      a.style.transition = 'opacity .5s';
      a.style.opacity = '0';
      setTimeout(() => a.remove(), 500);
    });
  }, 4000);
});
