<?php require_once 'config.php';
$pageTitle = 'Home';
$playlists = getPlaylists();
$searchQuery = '';
include 'includes/header.php'; ?>

<section class="hero">
  <div class="container">
    <h1>Master New Skills with <span class="text-primary">EduFlow</span></h1>
    <p>A professional learning platform connecting students with expert tutors through high-quality video courses.</p>

    <form class="hero-search" action="search.php" method="GET">
      <input type="search" name="q" placeholder="Search for courses, topics, or tutors..." value="<?= h($searchQuery) ?>">
      <button type="submit" class="btn btn-primary">Search</button>
    </form>

    <div class="hero-actions">
      <a href="courses.php" class="btn btn-primary btn-lg">Browse Courses</a>
      <a href="register.php" class="btn btn-outline btn-lg">Join for Free</a>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="stats-bar">
      <div class="stat-item">
        <div class="stat-icon">&#128100;</div>
        <div class="stat-number">10,000+</div>
        <div class="stat-label">Happy Students</div>
      </div>
      <div class="stat-item">
        <div class="stat-icon">&#128218;</div>
        <div class="stat-number">500+</div>
        <div class="stat-label">Expert Courses</div>
      </div>
      <div class="stat-item">
        <div class="stat-icon">&#127909;</div>
        <div class="stat-number">5,000+</div>
        <div class="stat-label">Video Lessons</div>
      </div>
    </div>
  </div>
</section>

<section class="section section-alt">
  <div class="container">
    <div class="section-header">
      <div>
        <h2>Latest Courses</h2>
        <p>Freshly added courses from our expert tutors</p>
      </div>
      <a href="courses.php" class="view-all">View all &rarr;</a>
    </div>

    <?php if ($playlists): ?>
      <div class="courses-grid">
        <?php foreach (array_slice($playlists, 0, 8) as $pl): ?>
          <a href="course_detail.php?id=<?= h($pl['id']) ?>" class="course-card">
            <div class="course-thumb">
              <img src="<?= getThumbnailUrl($pl['thumbnail'], $pl['title']) ?>" alt="<?= h($pl['title']) ?>" loading="lazy">
              <span class="course-category"><?= h($pl['category']) ?></span>
            </div>
            <div class="course-body">
              <div class="course-title"><?= h($pl['title']) ?></div>
              <div class="course-meta">
                <span class="course-tutor">&#127891; <?= h($pl['tutor_name']) ?></span>
                <span class="course-videos">&#127909; <?= (int)$pl['video_count'] ?> videos</span>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state"><div class="icon">&#128218;</div><h3>No courses yet</h3><p>Check back soon!</p></div>
    <?php endif; ?>
  </div>
</section>

<section class="cta-banner">
  <div class="container">
    <h2>Are You an Educator?</h2>
    <p>Share your knowledge with thousands of students. Create courses, upload videos, and build your teaching community on EduFlow.</p>
    <a href="admin/login.php" class="btn btn-lg" style="background:#fff;color:var(--primary)">Become a Tutor</a>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
