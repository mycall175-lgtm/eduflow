-- EduFlow LMS Database Schema
-- Import this file in phpMyAdmin on Namecheap

CREATE DATABASE IF NOT EXISTS eduflow_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE eduflow_db;

-- Tutors (educators / admins)
CREATE TABLE tutors (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    profession VARCHAR(100) DEFAULT 'Educator',
    profile TEXT,
    image VARCHAR(255) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Students
CREATE TABLE users (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    image VARCHAR(255) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Playlists (courses)
CREATE TABLE playlists (
    id VARCHAR(20) PRIMARY KEY,
    tutor_id VARCHAR(20) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    thumbnail VARCHAR(255) DEFAULT '',
    category VARCHAR(100) DEFAULT 'General',
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tutor_id) REFERENCES tutors(id) ON DELETE CASCADE
);

-- Content (video lessons)
CREATE TABLE content (
    id VARCHAR(20) PRIMARY KEY,
    playlist_id VARCHAR(20) NOT NULL,
    tutor_id VARCHAR(20) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    video_url VARCHAR(500) NOT NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
    FOREIGN KEY (tutor_id) REFERENCES tutors(id) ON DELETE CASCADE
);

-- Comments
CREATE TABLE comments (
    id VARCHAR(20) PRIMARY KEY,
    content_id VARCHAR(20) NOT NULL,
    user_id VARCHAR(20) NOT NULL,
    comment TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (content_id) REFERENCES content(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Likes
CREATE TABLE likes (
    id VARCHAR(20) PRIMARY KEY,
    content_id VARCHAR(20) NOT NULL,
    user_id VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_like (content_id, user_id),
    FOREIGN KEY (content_id) REFERENCES content(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Bookmarks
CREATE TABLE bookmarks (
    id VARCHAR(20) PRIMARY KEY,
    playlist_id VARCHAR(20) NOT NULL,
    user_id VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_bookmark (playlist_id, user_id),
    FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Contact messages
CREATE TABLE contacts (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    number VARCHAR(30) DEFAULT '',
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =============================================
-- SEED DATA
-- =============================================

-- Tutors (password: admin175)
INSERT INTO tutors (id, name, email, password, profession, profile, image) VALUES
('tutor_sarah_00001', 'Sarah Johnson', 'admin@eduflow.art', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Full Stack Developer', 'Experienced web developer and educator with over 8 years of teaching experience. Passionate about making complex topics simple and accessible.', ''),
('tutor_michael_001', 'Michael Chen', 'michael@eduflow.art', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'UI/UX Designer', 'Design educator focused on user experience, interface design, and creative problem solving. Helped 500+ students launch their design careers.', '');

-- NOTE: Default password hash above is for 'password' using PHP password_hash()
-- To use admin175, run: echo password_hash('admin175', PASSWORD_DEFAULT);
-- and replace the hash above, OR just register via the admin login page
-- For quick testing, insert with this hash (admin175):
UPDATE tutors SET password = '$2y$10$TKh8H1.PfuA2Pi92lLqnme.WQpVqXl3cY1GQIA5C.VGMfqgD7Qz5G' WHERE id = 'tutor_sarah_00001';
UPDATE tutors SET password = '$2y$10$TKh8H1.PfuA2Pi92lLqnme.WQpVqXl3cY1GQIA5C.VGMfqgD7Qz5G' WHERE id = 'tutor_michael_001';

-- Playlists
INSERT INTO playlists (id, tutor_id, title, description, thumbnail, category, status) VALUES
('pl_javascript_001', 'tutor_sarah_00001', 'JavaScript for Beginners', 'Master JavaScript from scratch. Learn variables, functions, DOM manipulation, and modern ES6+ features with practical projects.', '', 'Development', 'active'),
('pl_react_00000001', 'tutor_sarah_00001', 'React JS Complete Course', 'Build real-world React applications. Covers hooks, state management, routing, and API integration with hands-on projects.', '', 'Development', 'active'),
('pl_uiux_000000001', 'tutor_michael_001', 'UI/UX Design Fundamentals', 'Learn design principles, wireframing, prototyping, and user research. Create stunning interfaces with Figma from scratch.', '', 'Design', 'active'),
('pl_nodejs_00000001', 'tutor_sarah_00001', 'Node.js Backend Development', 'Build REST APIs with Node.js and Express. Learn databases, authentication, and deployment for production-ready backends.', '', 'Development', 'active');

-- Content (YouTube videos)
INSERT INTO content (id, playlist_id, tutor_id, title, description, video_url) VALUES
('ct_js_01', 'pl_javascript_001', 'tutor_sarah_00001', 'Introduction to JavaScript', 'What is JavaScript and why should you learn it? Overview of the language and its role in modern web development.', 'https://www.youtube.com/watch?v=W6NZfCO5SIk'),
('ct_js_02', 'pl_javascript_001', 'tutor_sarah_00001', 'Variables and Data Types', 'Learn about var, let, const, and the different data types in JavaScript including strings, numbers, and booleans.', 'https://www.youtube.com/watch?v=edlFjlzxkSI'),
('ct_js_03', 'pl_javascript_001', 'tutor_sarah_00001', 'Functions and Scope', 'Deep dive into JavaScript functions, arrow functions, scope, closures, and the this keyword.', 'https://www.youtube.com/watch?v=iLWTx5NchGw'),
('ct_react_01', 'pl_react_00000001', 'tutor_sarah_00001', 'What is React?', 'Introduction to React, its component-based architecture, and why it is the most popular frontend framework.', 'https://www.youtube.com/watch?v=Tn6-PIqc4UM'),
('ct_react_02', 'pl_react_00000001', 'tutor_sarah_00001', 'JSX and Components', 'Understanding JSX syntax and creating reusable React components with props and state management.', 'https://www.youtube.com/watch?v=9D1x7-2FmTA'),
('ct_react_03', 'pl_react_00000001', 'tutor_sarah_00001', 'React Hooks - useState & useEffect', 'Mastering the two most important React hooks for state and side effects in functional components.', 'https://www.youtube.com/watch?v=O6P86uwfdR0'),
('ct_uiux_01', 'pl_uiux_000000001', 'tutor_michael_001', 'Design Thinking Process', 'Learn the 5 stages of design thinking: Empathize, Define, Ideate, Prototype, and Test.', 'https://www.youtube.com/watch?v=_r0VX-aU_T8'),
('ct_uiux_02', 'pl_uiux_000000001', 'tutor_michael_001', 'Color Theory for Designers', 'Understanding color psychology, color wheels, and how to create effective color palettes for your projects.', 'https://www.youtube.com/watch?v=AvgCkHrcj90'),
('ct_uiux_03', 'pl_uiux_000000001', 'tutor_michael_001', 'Typography Fundamentals', 'Choosing the right fonts, understanding hierarchy, spacing, and readability for professional designs.', 'https://www.youtube.com/watch?v=hnDU1G9FiJM'),
('ct_node_01', 'pl_nodejs_00000001', 'tutor_sarah_00001', 'Node.js Introduction', 'What is Node.js, how does it work, and why use it for backend development? Setup and first server.', 'https://www.youtube.com/watch?v=TlB_eWDSMt4'),
('ct_node_02', 'pl_nodejs_00000001', 'tutor_sarah_00001', 'Express.js Framework', 'Building REST APIs with Express.js, routing, middleware, and handling HTTP requests and responses.', 'https://www.youtube.com/watch?v=L72fhGm1tfE'),
('ct_node_03', 'pl_nodejs_00000001', 'tutor_sarah_00001', 'Database Integration with MySQL', 'Connecting Node.js to MySQL, writing queries, and building a complete CRUD API with authentication.', 'https://www.youtube.com/watch?v=Hh_kiZTTBr0');

SELECT 'Database setup complete! Login: admin@eduflow.art / admin175' AS message;
