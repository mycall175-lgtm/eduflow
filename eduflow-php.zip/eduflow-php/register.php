<?php require_once 'config.php';
if (isStudent()) { header('Location: index.php'); exit; }
$pageTitle = 'Create Account';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $error = null;
    if (!$name || !$email || !$password) $error = 'Please fill in all fields.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $error = 'Please enter a valid email address.';
    elseif (strlen($password) < 6) $error = 'Password must be at least 6 characters.';
    elseif ($password !== $confirm) $error = 'Passwords do not match.';
    else {
        $db = getDB();
        $check = $db->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) $error = 'An account with this email already exists.';
        else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([uid(), $name, $email, $hash]);
            $user = $db->prepare("SELECT * FROM users WHERE email = ?");
            $user->execute([$email]);
            $u = $user->fetch();
            $_SESSION['user_id'] = $u['id'];
            $_SESSION['user_name'] = $u['name'];
            $_SESSION['user_email'] = $u['email'];
            flash('success', 'Account created! Welcome to EduFlow, ' . $name . '!');
            header('Location: index.php');
            exit;
        }
    }
}
include 'includes/header.php'; ?>

<div class="auth-page">
  <div class="auth-card">
    <div class="auth-logo">
      <div class="logo-icon">EF</div>
      <h2>Create your account</h2>
      <p>Join EduFlow and start learning today</p>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-error"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label class="form-label">Full Name</label>
        <input type="text" name="name" class="form-control" placeholder="John Smith" value="<?= h($_POST['name'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="you@example.com" value="<?= h($_POST['email'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Min. 6 characters" required>
      </div>
      <div class="form-group">
        <label class="form-label">Confirm Password</label>
        <input type="password" name="confirm_password" class="form-control" placeholder="Repeat your password" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Create Account</button>
    </form>

    <div class="auth-footer">
      Already have an account? <a href="login.php" class="text-primary">Sign in</a>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
