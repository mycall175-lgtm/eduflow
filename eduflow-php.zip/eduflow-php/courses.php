<?php require_once 'config.php';
$pageTitle = 'Courses';
$search = trim($_GET['q'] ?? $_GET['search'] ?? '');
$category = $_GET['category'] ?? '';
$playlists = getPlaylists($search, $category);
$categories = getCategories();
include 'includes/header.php'; ?>

<section class="page-header">
  <div class="container">
    <h1>Browse Courses</h1>
    <p>Find the perfect course to advance your skills.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <form method="GET" style="display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:2rem;align-items:center">
      <div class="search-bar" style="flex:1;margin:0;min-width:200px">
        <input type="search" name="q" placeholder="Search courses..." value="<?= h($search) ?>">
        <button type="submit" class="btn btn-primary">Search</button>
      </div>
      <select name="category" class="form-control" style="width:auto" onchange="this.form.submit()">
        <option value="">All Categories</option>
        <?php foreach ($categories as $cat): ?>
          <option value="<?= h($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= h($cat) ?></option>
        <?php endforeach; ?>
      </select>
      <?php if ($search || $category): ?>
        <a href="courses.php" class="btn btn-ghost btn-sm">Clear</a>
      <?php endif; ?>
    </form>

    <?php if ($search || $category): ?>
      <p class="text-muted text-small mb-2">
        <?= count($playlists) ?> result<?= count($playlists) !== 1 ? 's' : '' ?>
        <?= $search ? ' for "' . h($search) . '"' : '' ?>
        <?= $category ? ' in ' . h($category) : '' ?>
      </p>
    <?php endif; ?>

    <?php if ($playlists): ?>
      <div class="courses-grid">
        <?php foreach ($playlists as $pl): ?>
          <a href="course_detail.php?id=<?= h($pl['id']) ?>" class="course-card">
            <div class="course-thumb">
              <img src="<?= getThumbnailUrl($pl['thumbnail'], $pl['title']) ?>" alt="<?= h($pl['title']) ?>" loading="lazy">
              <span class="course-category"><?= h($pl['category']) ?></span>
            </div>
            <div class="course-body">
              <div class="course-title"><?= h($pl['title']) ?></div>
              <div class="course-meta">
                <span class="course-tutor">&#127891; <?= h($pl['tutor_name']) ?></span>
                <span class="course-videos">&#127909; <?= (int)$pl['video_count'] ?> videos</span>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state">
        <div class="icon">&#128218;</div>
        <h3>No courses found</h3>
        <p><?= ($search || $category) ? 'Try a different search.' : 'No courses available yet.' ?></p>
        <?php if ($search || $category): ?>
          <a href="courses.php" class="btn btn-primary" style="margin-top:1rem">View All Courses</a>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
