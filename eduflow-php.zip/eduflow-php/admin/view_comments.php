<?php require_once '../config.php';
requireTutor();
$pageTitle = 'Comments';
$db = getDB();
$stmt = $db->prepare("SELECT cm.*, u.name AS user_name, c.title AS content_title, c.id AS content_id FROM comments cm JOIN content c ON c.id=cm.content_id JOIN users u ON u.id=cm.user_id WHERE c.tutor_id=? ORDER BY cm.created_at DESC");
$stmt->execute([$_SESSION['tutor_id']]);
$comments = $stmt->fetchAll();
include '../includes/admin_header.php'; ?>

<div class="admin-header">
  <div><h1>Comments</h1><p class="text-muted"><?= count($comments) ?> comment<?= count($comments)!==1?'s':'' ?> on your videos</p></div>
</div>

<?php if ($comments): ?>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Student</th><th>Video</th><th>Comment</th><th>Date</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach ($comments as $c): ?>
          <tr>
            <td><strong class="text-small"><?= h($c['user_name']) ?></strong></td>
            <td><a href="<?= SITE_URL ?>/watch_video.php?id=<?= h($c['content_id']) ?>" target="_blank" class="text-primary text-small"><?= h($c['content_title']) ?></a></td>
            <td class="text-small"><?= h(substr($c['comment'],0,120)) ?><?= strlen($c['comment'])>120?'...':'' ?></td>
            <td class="text-small text-muted"><?= timeAgo($c['created_at']) ?></td>
            <td><a href="delete_comment.php?id=<?= h($c['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this comment?')">Delete</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php else: ?>
  <div class="empty-state"><div class="icon">&#128172;</div><h3>No comments yet</h3><p>Comments on your video lessons will appear here.</p></div>
<?php endif; ?>

<?php include '../includes/admin_footer.php'; ?>
