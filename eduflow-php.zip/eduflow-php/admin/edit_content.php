<?php require_once '../config.php';
requireTutor();
$id = $_GET['id'] ?? '';
$db = getDB();
$stmt = $db->prepare("SELECT * FROM content WHERE id=? AND tutor_id=?");
$stmt->execute([$id, $_SESSION['tutor_id']]);
$ct = $stmt->fetch();
if (!$ct) { flash('error','Video not found.'); header('Location: view_contents.php'); exit; }

$stmt = $db->prepare("SELECT id,title FROM playlists WHERE tutor_id=? ORDER BY title");
$stmt->execute([$_SESSION['tutor_id']]);
$playlists = $stmt->fetchAll();
$pageTitle = 'Edit Content';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $playlist_id = $_POST['playlist_id'] ?? $ct['playlist_id'];
    $title = trim($_POST['title'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $video_url = trim($_POST['video_url'] ?? '');
    $status = $_POST['status'] ?? 'active';
    if ($title && $video_url) {
        $db->prepare("UPDATE content SET playlist_id=?,title=?,description=?,video_url=?,status=? WHERE id=? AND tutor_id=?")
           ->execute([$playlist_id,$title,$desc,$video_url,$status,$id,$_SESSION['tutor_id']]);
        flash('success','Video updated!');
        header('Location: view_contents.php'); exit;
    } else { $error = 'Title and URL are required.'; }
}
include '../includes/admin_header.php'; ?>

<div class="admin-header">
  <div><h1>Edit Content</h1><p class="text-muted"><?= h($ct['title']) ?></p></div>
  <a href="view_contents.php" class="btn btn-ghost btn-sm">&larr; Back</a>
</div>
<?php if (!empty($error)): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>

<div class="admin-form-card">
  <form method="POST">
    <div class="form-group">
      <label class="form-label">Playlist</label>
      <select name="playlist_id" class="form-control">
        <?php foreach ($playlists as $pl): ?>
          <option value="<?= h($pl['id']) ?>" <?= $ct['playlist_id']===$pl['id']?'selected':'' ?>><?= h($pl['title']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">Title *</label>
      <input type="text" name="title" class="form-control" value="<?= h($ct['title']) ?>" required>
    </div>
    <div class="form-group">
      <label class="form-label">Video URL *</label>
      <input type="url" name="video_url" class="form-control" value="<?= h($ct['video_url']) ?>" required>
    </div>
    <div class="form-group">
      <label class="form-label">Description</label>
      <textarea name="description" class="form-control" rows="4"><?= h($ct['description']) ?></textarea>
    </div>
    <div class="form-group">
      <label class="form-label">Status</label>
      <select name="status" class="form-control">
        <option value="active" <?= $ct['status']==='active'?'selected':'' ?>>Active</option>
        <option value="inactive" <?= $ct['status']==='inactive'?'selected':'' ?>>Inactive</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Update Video</button>
    <a href="view_contents.php" class="btn btn-ghost" style="margin-left:.5rem">Cancel</a>
  </form>
</div>

<?php include '../includes/admin_footer.php'; ?>
