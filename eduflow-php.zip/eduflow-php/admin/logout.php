<?php require_once '../config.php';
unset($_SESSION['tutor_id'], $_SESSION['tutor_name'], $_SESSION['tutor_email']);
header('Location: login.php'); exit;
