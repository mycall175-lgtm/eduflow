<?php require_once '../config.php';
requireTutor();
$pageTitle = 'My Videos';
$db = getDB();
$stmt = $db->prepare("SELECT c.*, p.title AS playlist_title FROM content c JOIN playlists p ON p.id=c.playlist_id WHERE c.tutor_id=? ORDER BY c.created_at DESC");
$stmt->execute([$_SESSION['tutor_id']]);
$contents = $stmt->fetchAll();
include '../includes/admin_header.php'; ?>

<div class="admin-header">
  <div><h1>My Videos</h1><p class="text-muted"><?= count($contents) ?> video<?= count($contents)!==1?'s':'' ?></p></div>
  <a href="add_content.php" class="btn btn-primary btn-sm">+ Add Content</a>
</div>

<?php if ($contents): ?>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Title</th><th>Playlist</th><th>Video URL</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($contents as $c): ?>
          <tr>
            <td><strong><?= h($c['title']) ?></strong></td>
            <td><span class="badge badge-secondary"><?= h($c['playlist_title']) ?></span></td>
            <td><a href="<?= h($c['video_url']) ?>" target="_blank" class="text-primary text-small" style="max-width:200px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= h($c['video_url']) ?></a></td>
            <td><span class="badge <?= $c['status']==='active'?'badge-primary':'badge-secondary' ?>"><?= $c['status'] ?></span></td>
            <td>
              <a href="edit_content.php?id=<?= h($c['id']) ?>" class="btn btn-ghost btn-sm">Edit</a>
              <a href="delete_content.php?id=<?= h($c['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this video?')">Delete</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php else: ?>
  <div class="empty-state"><div class="icon">&#127909;</div><h3>No videos yet</h3><p><a href="add_content.php" class="text-primary">Add your first video</a></p></div>
<?php endif; ?>

<?php include '../includes/admin_footer.php'; ?>
