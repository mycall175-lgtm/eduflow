<?php require_once '../config.php';
requireTutor();
$id = $_GET['id'] ?? '';
$db = getDB();
$stmt = $db->prepare("SELECT id,title FROM playlists WHERE id=? AND tutor_id=?");
$stmt->execute([$id, $_SESSION['tutor_id']]);
$pl = $stmt->fetch();
if ($pl) {
    $db->prepare("DELETE FROM playlists WHERE id=? AND tutor_id=?")->execute([$id, $_SESSION['tutor_id']]);
    flash('success', '"' . $pl['title'] . '" deleted.');
} else { flash('error', 'Playlist not found.'); }
header('Location: view_playlists.php'); exit;
