<?php require_once '../config.php';
requireTutor();
$pageTitle = 'Profile';
$db = getDB();
$stmt = $db->prepare("SELECT * FROM tutors WHERE id=?");
$stmt->execute([$_SESSION['tutor_id']]);
$tutor = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $profession = trim($_POST['profession'] ?? '');
    $profile = trim($_POST['profile'] ?? '');
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    $error = null;
    if (!$name) $error = 'Name is required.';
    elseif ($newPassword && strlen($newPassword) < 6) $error = 'New password must be at least 6 characters.';
    elseif ($newPassword && $newPassword !== $confirmPassword) $error = 'Passwords do not match.';
    else {
        $image = handleUpload('image', 'tutors');
        if (!$image) $image = $tutor['image'];

        if ($newPassword) {
            $hash = password_hash($newPassword, PASSWORD_DEFAULT);
            $db->prepare("UPDATE tutors SET name=?,profession=?,profile=?,image=?,password=? WHERE id=?")
               ->execute([$name,$profession,$profile,$image,$hash,$_SESSION['tutor_id']]);
        } else {
            $db->prepare("UPDATE tutors SET name=?,profession=?,profile=?,image=? WHERE id=?")
               ->execute([$name,$profession,$profile,$image,$_SESSION['tutor_id']]);
        }
        $_SESSION['tutor_name'] = $name;
        // Refresh tutor data
        $stmt = $db->prepare("SELECT * FROM tutors WHERE id=?");
        $stmt->execute([$_SESSION['tutor_id']]);
        $tutor = $stmt->fetch();
        flash('success','Profile updated successfully!');
        header('Location: profile.php'); exit;
    }
}
include '../includes/admin_header.php'; ?>

<div class="admin-header">
  <div><h1>My Profile</h1><p class="text-muted">Update your public tutor profile</p></div>
</div>
<?php if (!empty($error)): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;align-items:start">
  <!-- Profile form -->
  <div class="admin-form-card" style="max-width:100%">
    <h3 style="margin-bottom:1.25rem;font-size:1rem;font-weight:700">Profile Information</h3>
    <form method="POST" enctype="multipart/form-data">
      <div class="form-group">
        <label class="form-label">Full Name *</label>
        <input type="text" name="name" class="form-control" value="<?= h($tutor['name']) ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Profession / Title</label>
        <input type="text" name="profession" class="form-control" value="<?= h($tutor['profession']) ?>" placeholder="e.g. Full Stack Developer">
      </div>
      <div class="form-group">
        <label class="form-label">Bio</label>
        <textarea name="profile" class="form-control" rows="5" placeholder="Tell students about yourself..."><?= h($tutor['profile']) ?></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Profile Photo <span class="text-muted text-small">(optional)</span></label>
        <input type="file" name="image" class="form-control" accept="image/*">
      </div>
      <div class="divider"></div>
      <h4 style="margin-bottom:1rem;font-size:.9rem;font-weight:700">Change Password <span class="text-muted text-small">(leave blank to keep current)</span></h4>
      <div class="form-group">
        <label class="form-label">New Password</label>
        <input type="password" name="new_password" class="form-control" placeholder="Min. 6 characters">
      </div>
      <div class="form-group">
        <label class="form-label">Confirm New Password</label>
        <input type="password" name="confirm_password" class="form-control" placeholder="Repeat new password">
      </div>
      <button type="submit" class="btn btn-primary">Save Changes</button>
    </form>
  </div>

  <!-- Profile preview -->
  <div class="admin-form-card" style="max-width:100%;text-align:center">
    <h3 style="margin-bottom:1.25rem;font-size:1rem;font-weight:700">Your Public Profile</h3>
    <div class="avatar avatar-lg" style="margin:0 auto 1rem"><?= strtoupper(substr($tutor['name'],0,1)) ?></div>
    <h3><?= h($tutor['name']) ?></h3>
    <p class="text-muted text-small"><?= h($tutor['profession']) ?></p>
    <?php if ($tutor['profile']): ?><p class="text-muted" style="margin-top:.75rem;font-size:.875rem;line-height:1.7"><?= nl2br(h($tutor['profile'])) ?></p><?php endif; ?>
    <div class="divider"></div>
    <p class="text-small text-muted"><strong>Email:</strong> <?= h($tutor['email']) ?></p>
    <a href="<?= SITE_URL ?>/teacher_detail.php?id=<?= h($tutor['id']) ?>" target="_blank" class="btn btn-outline btn-sm" style="margin-top:.75rem">View Public Profile</a>
  </div>
</div>

<?php include '../includes/admin_footer.php'; ?>
