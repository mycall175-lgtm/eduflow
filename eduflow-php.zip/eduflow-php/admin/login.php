<?php require_once '../config.php';
if (isTutor()) { header('Location: dashboard.php'); exit; }
$pageTitle = 'Tutor Login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($email && $password) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM tutors WHERE email = ?");
        $stmt->execute([$email]);
        $tutor = $stmt->fetch();
        if ($tutor && password_verify($password, $tutor['password'])) {
            $_SESSION['tutor_id'] = $tutor['id'];
            $_SESSION['tutor_name'] = $tutor['name'];
            $_SESSION['tutor_email'] = $tutor['email'];
            header('Location: dashboard.php'); exit;
        } else { $error = 'Invalid email or password.'; }
    } else { $error = 'Please fill in all fields.'; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Tutor Login — EduFlow</title>
  <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
  <script>(function(){var t=localStorage.getItem('eduflow-theme');if(t==='dark'||((!t)&&window.matchMedia('(prefers-color-scheme:dark)').matches))document.documentElement.classList.add('dark');})();</script>
</head>
<body>
<div class="auth-page">
  <div class="auth-card">
    <div class="auth-logo">
      <div class="logo-icon">EF</div>
      <h2>Tutor Dashboard</h2>
      <p>Sign in to manage your courses</p>
    </div>
    <?php if (!empty($error)): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>
    <form method="POST">
      <div class="form-group">
        <label class="form-label">Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="tutor@example.com" value="<?= h($_POST['email'] ?? '') ?>" required autofocus>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Your password" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Sign in to Dashboard</button>
    </form>
    <div class="auth-footer">
      <a href="<?= SITE_URL ?>/" class="text-primary">&larr; Back to EduFlow</a>
    </div>
    <div class="auth-footer" style="margin-top:.35rem;font-size:.75rem;color:var(--text3)">
      Demo: admin@eduflow.art / admin175
    </div>
  </div>
</div>
<script src="<?= SITE_URL ?>/js/main.js"></script>
</body></html>
