<?php require_once '../config.php';
requireTutor();
$id = $_GET['id'] ?? '';
$db = getDB();
$stmt = $db->prepare("SELECT * FROM playlists WHERE id=? AND tutor_id=?");
$stmt->execute([$id, $_SESSION['tutor_id']]);
$pl = $stmt->fetch();
if (!$pl) { flash('error','Playlist not found.'); header('Location: view_playlists.php'); exit; }
$pageTitle = 'Edit Playlist';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? 'General');
    $status = $_POST['status'] ?? 'active';
    if ($title) {
        $thumb = handleUpload('thumbnail', 'thumbnails');
        if (!$thumb) $thumb = $pl['thumbnail'];
        $db->prepare("UPDATE playlists SET title=?,description=?,category=?,status=?,thumbnail=? WHERE id=? AND tutor_id=?")
           ->execute([$title,$desc,$category,$status,$thumb,$id,$_SESSION['tutor_id']]);
        flash('success', 'Playlist updated!');
        header('Location: view_playlists.php'); exit;
    } else { $error = 'Title is required.'; }
}

$categories = ['Development','Design','Business','Marketing','Science','Language','Music','Other'];
include '../includes/admin_header.php'; ?>

<div class="admin-header">
  <div><h1>Edit Playlist</h1><p class="text-muted"><?= h($pl['title']) ?></p></div>
  <a href="view_playlists.php" class="btn btn-ghost btn-sm">&larr; Back</a>
</div>

<?php if (!empty($error)): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>

<div class="admin-form-card">
  <form method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label class="form-label">Playlist Title *</label>
      <input type="text" name="title" class="form-control" value="<?= h($pl['title']) ?>" required>
    </div>
    <div class="form-group">
      <label class="form-label">Description</label>
      <textarea name="description" class="form-control" rows="4"><?= h($pl['description']) ?></textarea>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
      <div class="form-group">
        <label class="form-label">Category</label>
        <select name="category" class="form-control">
          <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat ?>" <?= $pl['category']===$cat?'selected':'' ?>><?= $cat ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Status</label>
        <select name="status" class="form-control">
          <option value="active" <?= $pl['status']==='active'?'selected':'' ?>>Active</option>
          <option value="inactive" <?= $pl['status']==='inactive'?'selected':'' ?>>Inactive</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Thumbnail <span class="text-muted text-small">(leave blank to keep current)</span></label>
      <?php if ($pl['thumbnail']): ?>
        <img src="<?= getThumbnailUrl($pl['thumbnail'], $pl['title']) ?>" style="width:200px;border-radius:8px;margin-bottom:.5rem" alt="">
      <?php endif; ?>
      <input type="file" name="thumbnail" class="form-control" accept="image/*">
    </div>
    <button type="submit" class="btn btn-primary">Update Playlist</button>
    <a href="view_playlists.php" class="btn btn-ghost" style="margin-left:.5rem">Cancel</a>
  </form>
</div>

<?php include '../includes/admin_footer.php'; ?>
