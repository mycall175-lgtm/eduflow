<?php require_once '../config.php';
requireTutor();
$pageTitle = 'Add Content';
$db = getDB();
$stmt = $db->prepare("SELECT id,title FROM playlists WHERE tutor_id=? AND status='active' ORDER BY title");
$stmt->execute([$_SESSION['tutor_id']]);
$playlists = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $playlist_id = $_POST['playlist_id'] ?? '';
    $title = trim($_POST['title'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $video_url = trim($_POST['video_url'] ?? '');
    $status = $_POST['status'] ?? 'active';

    if ($playlist_id && $title && $video_url) {
        $db->prepare("INSERT INTO content (id, playlist_id, tutor_id, title, description, video_url, status) VALUES (?,?,?,?,?,?,?)")
           ->execute([uid(), $playlist_id, $_SESSION['tutor_id'], $title, $desc, $video_url, $status]);
        flash('success', 'Video "' . $title . '" added!');
        header('Location: view_contents.php'); exit;
    } else { $error = 'Please fill in all required fields.'; }
}
include '../includes/admin_header.php'; ?>

<div class="admin-header">
  <div><h1>Add Content</h1><p class="text-muted">Add a new video lesson to a playlist</p></div>
  <a href="view_contents.php" class="btn btn-ghost btn-sm">&larr; Back</a>
</div>

<?php if (!empty($error)): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>
<?php if (!$playlists): ?><div class="alert alert-info">You need to <a href="add_playlist.php" class="text-primary fw-600">create a playlist</a> first before adding content.</div><?php endif; ?>

<div class="admin-form-card">
  <form method="POST">
    <div class="form-group">
      <label class="form-label">Playlist *</label>
      <select name="playlist_id" class="form-control" required>
        <option value="">— Select a playlist —</option>
        <?php foreach ($playlists as $pl): ?>
          <option value="<?= h($pl['id']) ?>" <?= ($_POST['playlist_id']??'')===$pl['id']?'selected':'' ?>><?= h($pl['title']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">Video Title *</label>
      <input type="text" name="title" class="form-control" placeholder="e.g. Introduction to Variables" value="<?= h($_POST['title'] ?? '') ?>" required>
    </div>
    <div class="form-group">
      <label class="form-label">Video URL * <span class="text-muted text-small">(YouTube link or direct video URL)</span></label>
      <input type="url" name="video_url" class="form-control" placeholder="https://www.youtube.com/watch?v=..." value="<?= h($_POST['video_url'] ?? '') ?>" required>
      <p class="form-hint">YouTube links are automatically embedded as a responsive player.</p>
    </div>
    <div class="form-group">
      <label class="form-label">Description</label>
      <textarea name="description" class="form-control" rows="4" placeholder="What will students learn in this lesson?"><?= h($_POST['description'] ?? '') ?></textarea>
    </div>
    <div class="form-group">
      <label class="form-label">Status</label>
      <select name="status" class="form-control">
        <option value="active">Active (visible to students)</option>
        <option value="inactive">Inactive (draft)</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Add Video</button>
    <a href="view_contents.php" class="btn btn-ghost" style="margin-left:.5rem">Cancel</a>
  </form>
</div>

<?php include '../includes/admin_footer.php'; ?>
