<?php require_once '../config.php';
requireTutor();
$id = $_GET['id'] ?? '';
$db = getDB();
$stmt = $db->prepare("SELECT id,title FROM content WHERE id=? AND tutor_id=?");
$stmt->execute([$id, $_SESSION['tutor_id']]);
$ct = $stmt->fetch();
if ($ct) {
    $db->prepare("DELETE FROM content WHERE id=? AND tutor_id=?")->execute([$id,$_SESSION['tutor_id']]);
    flash('success', '"' . $ct['title'] . '" deleted.');
} else { flash('error','Video not found.'); }
header('Location: view_contents.php'); exit;
