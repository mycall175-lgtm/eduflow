<?php require_once '../config.php';
requireTutor();
$id = $_GET['id'] ?? '';
$db = getDB();
$stmt = $db->prepare("SELECT cm.id FROM comments cm JOIN content c ON c.id=cm.content_id WHERE cm.id=? AND c.tutor_id=?");
$stmt->execute([$id, $_SESSION['tutor_id']]);
if ($stmt->fetch()) {
    $db->prepare("DELETE FROM comments WHERE id=?")->execute([$id]);
    flash('success','Comment deleted.');
} else { flash('error','Comment not found.'); }
header('Location: view_comments.php'); exit;
