<?php require_once '../config.php';
requireTutor();
$pageTitle = 'Dashboard';
$db = getDB();
$tid = $_SESSION['tutor_id'];

$plCount = (int)$db->prepare("SELECT COUNT(*) FROM playlists WHERE tutor_id=?")->execute([$tid]) ? 0 : 0;
$stmt = $db->prepare("SELECT COUNT(*) FROM playlists WHERE tutor_id=?"); $stmt->execute([$tid]); $plCount=(int)$stmt->fetchColumn();
$stmt = $db->prepare("SELECT COUNT(*) FROM content WHERE tutor_id=?"); $stmt->execute([$tid]); $vidCount=(int)$stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM likes l JOIN content c ON c.id=l.content_id WHERE c.tutor_id=?");
$stmt->execute([$tid]); $likeCount=(int)$stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM comments cm JOIN content c ON c.id=cm.content_id WHERE c.tutor_id=?");
$stmt->execute([$tid]); $commentCount=(int)$stmt->fetchColumn();

$stmt = $db->prepare("SELECT cm.*, u.name AS user_name, c.title AS content_title FROM comments cm JOIN content c ON c.id=cm.content_id JOIN users u ON u.id=cm.user_id WHERE c.tutor_id=? ORDER BY cm.created_at DESC LIMIT 5");
$stmt->execute([$tid]); $recentComments=$stmt->fetchAll();

$stmt = $db->prepare("SELECT p.*, (SELECT COUNT(*) FROM content c WHERE c.playlist_id=p.id) AS video_count FROM playlists p WHERE p.tutor_id=? ORDER BY p.created_at DESC LIMIT 5");
$stmt->execute([$tid]); $recentPlaylists=$stmt->fetchAll();

include '../includes/admin_header.php'; ?>

<div class="admin-header">
  <div>
    <h1>Dashboard</h1>
    <p class="text-muted">Welcome back, <?= h($_SESSION['tutor_name']) ?></p>
  </div>
  <a href="add_playlist.php" class="btn btn-primary btn-sm">+ New Course</a>
</div>

<div class="admin-stats">
  <div class="stat-card"><div class="stat-card-icon">&#128218;</div><div class="stat-card-info"><div class="stat-card-num"><?= $plCount ?></div><div class="stat-card-label">Playlists</div></div></div>
  <div class="stat-card"><div class="stat-card-icon">&#127909;</div><div class="stat-card-info"><div class="stat-card-num"><?= $vidCount ?></div><div class="stat-card-label">Videos</div></div></div>
  <div class="stat-card"><div class="stat-card-icon">&#128077;</div><div class="stat-card-info"><div class="stat-card-num"><?= $likeCount ?></div><div class="stat-card-label">Total Likes</div></div></div>
  <div class="stat-card"><div class="stat-card-icon">&#128172;</div><div class="stat-card-info"><div class="stat-card-num"><?= $commentCount ?></div><div class="stat-card-label">Comments</div></div></div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-top:1.5rem">
  <div class="admin-table-wrap">
    <div style="padding:1rem 1.25rem;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
      <strong>Recent Playlists</strong>
      <a href="view_playlists.php" class="view-all">View all</a>
    </div>
    <?php if ($recentPlaylists): ?>
      <table class="admin-table">
        <tr><?php foreach ($recentPlaylists as $pl): ?>
          <tr>
            <td><strong class="text-small"><?= h($pl['title']) ?></strong><br><span class="text-muted text-small"><?= (int)$pl['video_count'] ?> videos</span></td>
            <td><span class="badge <?= $pl['status']==='active'?'badge-primary':'badge-secondary' ?>"><?= $pl['status'] ?></span></td>
            <td><a href="edit_playlist.php?id=<?= h($pl['id']) ?>" class="btn btn-ghost btn-sm">Edit</a></td>
          </tr>
        <?php endforeach; ?>
      </table>
    <?php else: ?><div class="empty-state" style="padding:2rem"><p>No playlists yet. <a href="add_playlist.php" class="text-primary">Create one</a></p></div><?php endif; ?>
  </div>

  <div class="admin-table-wrap">
    <div style="padding:1rem 1.25rem;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
      <strong>Recent Comments</strong>
      <a href="view_comments.php" class="view-all">View all</a>
    </div>
    <?php if ($recentComments): ?>
      <div style="padding:.5rem 1rem">
        <?php foreach ($recentComments as $c): ?>
          <div style="padding:.75rem 0;border-bottom:1px solid var(--border)">
            <div class="flex-between">
              <span class="text-small fw-600"><?= h($c['user_name']) ?></span>
              <span class="text-small text-muted"><?= timeAgo($c['created_at']) ?></span>
            </div>
            <div class="text-small text-primary" style="margin:.15rem 0"><?= h($c['content_title']) ?></div>
            <div class="text-small text-muted truncate-2"><?= h($c['comment']) ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?><div class="empty-state" style="padding:2rem"><p>No comments yet.</p></div><?php endif; ?>
  </div>
</div>

<?php include '../includes/admin_footer.php'; ?>
