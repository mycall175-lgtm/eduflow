<?php require_once '../config.php';
requireTutor();
$pageTitle = 'Add Playlist';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? 'General');
    $status = $_POST['status'] ?? 'active';

    if ($title) {
        $thumb = handleUpload('thumbnail', 'thumbnails');
        $db = getDB();
        $db->prepare("INSERT INTO playlists (id, tutor_id, title, description, thumbnail, category, status) VALUES (?,?,?,?,?,?,?)")
           ->execute([uid(), $_SESSION['tutor_id'], $title, $desc, $thumb, $category, $status]);
        flash('success', 'Playlist "' . $title . '" created successfully!');
        header('Location: view_playlists.php'); exit;
    } else { $error = 'Title is required.'; }
}

$categories = ['Development','Design','Business','Marketing','Science','Language','Music','Other'];
include '../includes/admin_header.php'; ?>

<div class="admin-header">
  <div><h1>Add Playlist</h1><p class="text-muted">Create a new course playlist</p></div>
  <a href="view_playlists.php" class="btn btn-ghost btn-sm">&larr; Back</a>
</div>

<?php if (!empty($error)): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>

<div class="admin-form-card">
  <form method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label class="form-label">Playlist Title *</label>
      <input type="text" name="title" class="form-control" placeholder="e.g. JavaScript for Beginners" value="<?= h($_POST['title'] ?? '') ?>" required>
    </div>
    <div class="form-group">
      <label class="form-label">Description</label>
      <textarea name="description" class="form-control" rows="4" placeholder="Describe what students will learn..."><?= h($_POST['description'] ?? '') ?></textarea>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
      <div class="form-group">
        <label class="form-label">Category</label>
        <select name="category" class="form-control">
          <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat ?>" <?= ($_POST['category'] ?? '') === $cat ? 'selected' : '' ?>><?= $cat ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Status</label>
        <select name="status" class="form-control">
          <option value="active">Active (visible to students)</option>
          <option value="inactive">Inactive (draft)</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Thumbnail Image <span class="text-muted text-small">(optional, JPG/PNG)</span></label>
      <input type="file" name="thumbnail" class="form-control" accept="image/*">
      <p class="form-hint">Recommended: 1280x720px (16:9 ratio)</p>
    </div>
    <button type="submit" class="btn btn-primary">Create Playlist</button>
    <a href="view_playlists.php" class="btn btn-ghost" style="margin-left:.5rem">Cancel</a>
  </form>
</div>

<?php include '../includes/admin_footer.php'; ?>
