<?php require_once '../config.php';
requireTutor();
$pageTitle = 'My Playlists';
$db = getDB();
$stmt = $db->prepare("SELECT p.*, (SELECT COUNT(*) FROM content c WHERE c.playlist_id=p.id) AS video_count FROM playlists p WHERE p.tutor_id=? ORDER BY p.created_at DESC");
$stmt->execute([$_SESSION['tutor_id']]);
$playlists = $stmt->fetchAll();
include '../includes/admin_header.php'; ?>

<div class="admin-header">
  <div><h1>My Playlists</h1><p class="text-muted"><?= count($playlists) ?> course<?= count($playlists)!==1?'s':'' ?></p></div>
  <a href="add_playlist.php" class="btn btn-primary btn-sm">+ Add Playlist</a>
</div>

<?php if ($playlists): ?>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Thumbnail</th><th>Title</th><th>Category</th><th>Videos</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($playlists as $pl): ?>
          <tr>
            <td><img src="<?= getThumbnailUrl($pl['thumbnail'], $pl['title']) ?>" class="thumb-sm" alt=""></td>
            <td>
              <strong><?= h($pl['title']) ?></strong>
              <div class="text-muted text-small truncate-2" style="max-width:280px"><?= h(substr($pl['description'],0,80)) ?>...</div>
            </td>
            <td><span class="badge badge-secondary"><?= h($pl['category']) ?></span></td>
            <td><?= (int)$pl['video_count'] ?></td>
            <td><span class="badge <?= $pl['status']==='active'?'badge-primary':'badge-secondary' ?>"><?= $pl['status'] ?></span></td>
            <td>
              <a href="edit_playlist.php?id=<?= h($pl['id']) ?>" class="btn btn-ghost btn-sm">Edit</a>
              <a href="delete_playlist.php?id=<?= h($pl['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this playlist and all its videos?')">Delete</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php else: ?>
  <div class="empty-state"><div class="icon">&#128218;</div><h3>No playlists yet</h3><p><a href="add_playlist.php" class="text-primary">Create your first course</a></p></div>
<?php endif; ?>

<?php include '../includes/admin_footer.php'; ?>
