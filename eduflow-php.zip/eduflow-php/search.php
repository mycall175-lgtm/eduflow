<?php require_once 'config.php';
$pageTitle = 'Search';
$q = trim($_GET['q'] ?? '');
$playlists = $q ? getPlaylists($q) : [];
$tutors = [];
if ($q) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM tutors WHERE name LIKE ? OR profession LIKE ? OR profile LIKE ?");
    $stmt->execute(["%$q%", "%$q%", "%$q%"]);
    $tutors = $stmt->fetchAll();
}
include 'includes/header.php'; ?>

<section class="page-header">
  <div class="container">
    <h1>Search</h1>
    <p>Find courses, tutors, and topics across EduFlow.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <form method="GET" class="search-bar" style="max-width:700px;margin-bottom:2.5rem">
      <input type="search" name="q" placeholder="Search for courses, tutors, topics..." value="<?= h($q) ?>" autofocus>
      <button type="submit" class="btn btn-primary">Search</button>
    </form>

    <?php if ($q): ?>
      <p class="text-muted text-small mb-2">
        Showing results for "<strong><?= h($q) ?></strong>" — <?= count($playlists) ?> course<?= count($playlists) !== 1 ? 's' : '' ?>, <?= count($tutors) ?> tutor<?= count($tutors) !== 1 ? 's' : '' ?>
      </p>

      <?php if ($playlists): ?>
        <h2 style="font-size:1.1rem;font-weight:700;margin-bottom:1rem">Courses</h2>
        <div class="courses-grid" style="margin-bottom:2.5rem">
          <?php foreach ($playlists as $pl): ?>
            <a href="course_detail.php?id=<?= h($pl['id']) ?>" class="course-card">
              <div class="course-thumb">
                <img src="<?= getThumbnailUrl($pl['thumbnail'], $pl['title']) ?>" alt="<?= h($pl['title']) ?>" loading="lazy">
                <span class="course-category"><?= h($pl['category']) ?></span>
              </div>
              <div class="course-body">
                <div class="course-title"><?= h($pl['title']) ?></div>
                <div class="course-meta">
                  <span class="course-tutor">&#127891; <?= h($pl['tutor_name']) ?></span>
                  <span class="course-videos">&#127909; <?= (int)$pl['video_count'] ?> videos</span>
                </div>
              </div>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <?php if ($tutors): ?>
        <h2 style="font-size:1.1rem;font-weight:700;margin-bottom:1rem">Tutors</h2>
        <div class="teachers-grid">
          <?php foreach ($tutors as $t): ?>
            <a href="teacher_detail.php?id=<?= h($t['id']) ?>" class="teacher-card">
              <div class="teacher-avatar-wrap"><?= strtoupper(substr($t['name'], 0, 1)) ?></div>
              <div class="teacher-name"><?= h($t['name']) ?></div>
              <div class="teacher-profession text-muted"><?= h($t['profession']) ?></div>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <?php if (!$playlists && !$tutors): ?>
        <div class="empty-state">
          <div class="icon">&#128269;</div>
          <h3>No results found</h3>
          <p>Try different keywords or browse our <a href="courses.php" class="text-primary">course library</a>.</p>
        </div>
      <?php endif; ?>

    <?php else: ?>
      <div class="empty-state">
        <div class="icon">&#128269;</div>
        <h3>Start searching</h3>
        <p>Type a keyword above to search for courses and tutors.</p>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
