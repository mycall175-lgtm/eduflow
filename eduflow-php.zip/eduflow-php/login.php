<?php require_once 'config.php';
if (isStudent()) { header('Location: index.php'); exit; }
$pageTitle = 'Student Login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            flash('success', 'Welcome back, ' . $user['name'] . '!');
            header('Location: ' . ($_GET['redirect'] ?? 'index.php'));
            exit;
        } else {
            $error = 'Invalid email or password.';
        }
    } else {
        $error = 'Please fill in all fields.';
    }
}
include 'includes/header.php'; ?>

<div class="auth-page">
  <div class="auth-card">
    <div class="auth-logo">
      <div class="logo-icon">EF</div>
      <h2>Welcome back</h2>
      <p>Sign in to your EduFlow account</p>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-error"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label class="form-label">Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="you@example.com" value="<?= h($_POST['email'] ?? '') ?>" required autofocus>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Your password" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Sign in</button>
    </form>

    <div class="auth-footer">
      Don't have an account? <a href="register.php" class="text-primary">Sign up free</a>
    </div>
    <div class="auth-footer" style="margin-top:.5rem">
      Are you a tutor? <a href="admin/login.php" class="text-primary">Tutor login</a>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
