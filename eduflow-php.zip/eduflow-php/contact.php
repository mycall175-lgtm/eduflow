<?php require_once 'config.php';
$pageTitle = 'Contact';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $number = trim($_POST['number'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name && $email && filter_var($email, FILTER_VALIDATE_EMAIL) && $message) {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO contacts (id, name, email, number, message) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([uid(), $name, $email, $number, $message]);
        flash('success', 'Your message has been sent! We will get back to you shortly.');
        header('Location: contact.php');
        exit;
    } else {
        $error = 'Please fill in all required fields with a valid email.';
    }
}

include 'includes/header.php'; ?>

<section class="hero" style="padding:4rem 0">
  <div class="container">
    <h1>Contact <span class="text-primary">Us</span></h1>
    <p>Have questions, feedback, or want to become a tutor on EduFlow? We would love to hear from you.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="contact-grid">
      <div>
        <h2 style="font-size:1.5rem;font-weight:700;margin-bottom:1.5rem">Get in Touch</h2>
        <p class="text-muted" style="margin-bottom:2rem;line-height:1.7">Whether you are a student looking for support or a tutor wanting to list your courses, our team is here to help.</p>

        <div class="contact-info-item">
          <div class="contact-icon">&#9993;</div>
          <div>
            <strong>Email</strong><br>
            <span class="text-muted text-small">support@eduflow.art</span>
          </div>
        </div>
        <div class="contact-info-item">
          <div class="contact-icon">&#128222;</div>
          <div>
            <strong>Phone</strong><br>
            <span class="text-muted text-small">+1 (800) EDU-FLOW</span>
          </div>
        </div>
        <div class="contact-info-item">
          <div class="contact-icon">&#128205;</div>
          <div>
            <strong>Location</strong><br>
            <span class="text-muted text-small">Available worldwide — fully online</span>
          </div>
        </div>
      </div>

      <div class="contact-form">
        <?php if (!empty($error)): ?>
          <div class="alert alert-error"><?= h($error) ?></div>
        <?php endif; ?>

        <h3>Send a Message</h3>
        <form method="POST">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Your Name *</label>
              <input type="text" name="name" class="form-control" placeholder="John Smith" value="<?= h($_POST['name'] ?? '') ?>" required>
            </div>
            <div class="form-group">
              <label class="form-label">Email Address *</label>
              <input type="email" name="email" class="form-control" placeholder="john@example.com" value="<?= h($_POST['email'] ?? '') ?>" required>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Phone Number <span class="text-muted text-small">(optional)</span></label>
            <input type="tel" name="number" class="form-control" placeholder="+1 234 567 8900" value="<?= h($_POST['number'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Message *</label>
            <textarea name="message" class="form-control" rows="5" placeholder="How can we help you?" required><?= h($_POST['message'] ?? '') ?></textarea>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%">&#9993; Send Message</button>
        </form>
      </div>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
