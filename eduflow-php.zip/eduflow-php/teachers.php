<?php require_once 'config.php';
$pageTitle = 'Teachers';
$tutors = getTutors();
include 'includes/header.php'; ?>

<section class="page-header">
  <div class="container">
    <h1>Our Teachers</h1>
    <p>Learn from passionate experts who are dedicated to your success.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <?php if ($tutors): ?>
      <div class="teachers-grid">
        <?php foreach ($tutors as $t): ?>
          <a href="teacher_detail.php?id=<?= h($t['id']) ?>" class="teacher-card">
            <div class="teacher-avatar-wrap"><?= strtoupper(substr($t['name'], 0, 1)) ?></div>
            <div class="teacher-name"><?= h($t['name']) ?></div>
            <div class="teacher-profession text-muted"><?= h($t['profession']) ?></div>
            <div style="margin-top:.5rem"><span class="badge badge-primary">&#128218; <?= (int)$t['playlist_count'] ?> Course<?= $t['playlist_count'] != 1 ? 's' : '' ?></span></div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state"><div class="icon">&#127979;</div><h3>No tutors yet</h3></div>
    <?php endif; ?>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
