<?php require_once 'config.php';
$id = $_GET['id'] ?? '';
$playlist = $id ? getPlaylist($id) : null;
if (!$playlist) { header('Location: courses.php'); exit; }
$videos = getPlaylistVideos($id);
$pageTitle = $playlist['title'];
include 'includes/header.php'; ?>

<section class="course-detail-hero">
  <div class="container">
    <div class="breadcrumb">
      <a href="courses.php">Courses</a>
      <span>›</span>
      <span><?= h($playlist['title']) ?></span>
    </div>
    <div class="course-detail-grid">
      <div class="course-info">
        <span class="badge badge-primary" style="margin-bottom:.75rem"><?= h($playlist['category']) ?></span>
        <h1><?= h($playlist['title']) ?></h1>
        <p style="margin:1rem 0;line-height:1.7"><?= h($playlist['description']) ?></p>
        <div class="tutor-card-small" style="max-width:380px">
          <div class="avatar"><?= strtoupper(substr($playlist['tutor_name'], 0, 1)) ?></div>
          <div>
            <div class="fw-600"><?= h($playlist['tutor_name']) ?></div>
            <div class="text-muted text-small"><?= h($playlist['tutor_profession']) ?></div>
          </div>
        </div>
        <div style="display:flex;gap:1.5rem;font-size:.875rem;color:var(--text2);margin-top:.75rem">
          <span>&#127909; <?= count($videos) ?> video<?= count($videos) !== 1 ? 's' : '' ?></span>
          <?php if (count($videos) > 0): ?>
            <span>&#128336; Added <?= date('M Y', strtotime($playlist['created_at'])) ?></span>
          <?php endif; ?>
        </div>
        <?php if ($videos): ?>
          <a href="watch_video.php?id=<?= h($videos[0]['id']) ?>" class="btn btn-primary" style="margin-top:1.25rem;display:inline-flex">&#9654; Start Watching</a>
        <?php endif; ?>
      </div>

      <div class="course-sidebar">
        <img src="<?= getThumbnailUrl($playlist['thumbnail'], $playlist['title']) ?>" alt="<?= h($playlist['title']) ?>" class="course-sidebar-thumb">
        <?php if ($videos): ?>
          <h3 style="font-size:.95rem;font-weight:700;margin-bottom:.75rem">Course Content</h3>
          <div style="display:flex;flex-direction:column;gap:.35rem">
            <?php foreach ($videos as $i => $v): ?>
              <a href="watch_video.php?id=<?= h($v['id']) ?>" class="playlist-item">
                <div class="playlist-num"><?= $i + 1 ?></div>
                <div class="playlist-title"><?= h($v['title']) ?></div>
              </a>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="empty-state" style="padding:2rem 1rem">
            <div class="icon">&#127909;</div>
            <p>No videos yet.</p>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
