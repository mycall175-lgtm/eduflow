<?php require_once 'config.php';
$id = $_GET['id'] ?? '';
$video = $id ? getVideo($id) : null;
if (!$video) { header('Location: courses.php'); exit; }

$playlist = getPlaylist($video['playlist_id']);
$playlistVideos = getPlaylistVideos($video['playlist_id']);
$comments = getComments($id);
$likeCount = getLikeCount($id);
$liked = hasLiked($id, $_SESSION['user_id'] ?? null);
$bookmarked = hasBookmarked($video['playlist_id'], $_SESSION['user_id'] ?? null);

$embedUrl = isYouTube($video['video_url']) ? getYouTubeEmbed($video['video_url']) : '';
$pageTitle = $video['title'];
include 'includes/header.php'; ?>

<div class="container">
  <div class="watch-grid">
    <div>
      <!-- Video Player -->
      <div class="video-player-wrap">
        <?php if ($embedUrl): ?>
          <iframe src="<?= h($embedUrl) ?>"
            title="<?= h($video['title']) ?>"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen></iframe>
        <?php else: ?>
          <video src="<?= h($video['video_url']) ?>" controls></video>
        <?php endif; ?>
      </div>

      <!-- Video Info -->
      <div class="video-info">
        <div class="breadcrumb mt-1">
          <a href="courses.php">Courses</a>
          <span>›</span>
          <a href="course_detail.php?id=<?= h($video['playlist_id']) ?>"><?= h($video['playlist_title']) ?></a>
          <span>›</span>
          <span><?= h($video['title']) ?></span>
        </div>
        <h1><?= h($video['title']) ?></h1>

        <div class="video-actions">
          <button class="like-btn <?= $liked ? 'liked' : '' ?>"
            onclick="toggleLike(this, '<?= h($id) ?>')">
            &#128077; <span class="like-count"><?= $likeCount ?></span> Like<?= $likeCount !== 1 ? 's' : '' ?>
          </button>
          <button class="bookmark-btn <?= $bookmarked ? 'bookmarked' : '' ?>"
            onclick="toggleBookmark(this, '<?= h($video['playlist_id']) ?>')">
            &#128278; <span class="bm-label"><?= $bookmarked ? 'Bookmarked' : 'Bookmark' ?></span>
          </button>
          <a href="course_detail.php?id=<?= h($video['playlist_id']) ?>" class="btn btn-ghost btn-sm">&#128218; Course Page</a>
        </div>

        <div class="tutor-card-small">
          <div class="avatar"><?= strtoupper(substr($video['tutor_name'], 0, 1)) ?></div>
          <div>
            <div class="fw-600"><?= h($video['tutor_name']) ?></div>
            <div class="text-muted text-small"><?= h($video['tutor_profession']) ?></div>
          </div>
        </div>

        <?php if ($video['description']): ?>
          <div class="video-description"><?= nl2br(h($video['description'])) ?></div>
        <?php endif; ?>

        <!-- Comments -->
        <div class="comments-section">
          <h3>&#128172; <?= count($comments) ?> Comment<?= count($comments) !== 1 ? 's' : '' ?></h3>

          <?php if (isStudent()): ?>
            <form class="comment-form" method="POST" action="actions/comment.php">
              <input type="hidden" name="content_id" value="<?= h($id) ?>">
              <input type="hidden" name="redirect" value="watch_video.php?id=<?= h($id) ?>">
              <div class="avatar avatar-sm"><?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?></div>
              <textarea name="comment" placeholder="Add a comment..." required></textarea>
              <button type="submit" class="btn btn-primary btn-sm">Post</button>
            </form>
          <?php else: ?>
            <div class="alert alert-info" style="margin-bottom:1.5rem;display:flex;align-items:center;justify-content:space-between">
              <span>Log in to leave a comment</span>
              <a href="login.php" class="btn btn-outline btn-sm">Log in</a>
            </div>
          <?php endif; ?>

          <?php if ($comments): ?>
            <?php foreach ($comments as $c): ?>
              <div class="comment">
                <div class="avatar avatar-sm"><?= strtoupper(substr($c['user_name'], 0, 1)) ?></div>
                <div class="comment-body">
                  <span class="comment-author"><?= h($c['user_name']) ?></span>
                  <span class="comment-time"><?= timeAgo($c['created_at']) ?></span>
                  <p class="comment-text"><?= nl2br(h($c['comment'])) ?></p>
                </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p class="text-muted text-small" style="text-align:center;padding:2rem;border:1px dashed var(--border);border-radius:var(--radius-sm)">No comments yet. Be the first to comment!</p>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Playlist Sidebar -->
    <div class="playlist-sidebar">
      <div class="playlist-sidebar-header">
        <h3><?= h($video['playlist_title']) ?></h3>
        <p><?= h($video['tutor_name']) ?> &bull; <?= count($playlistVideos) ?> videos</p>
      </div>
      <div class="playlist-videos">
        <?php foreach ($playlistVideos as $i => $v): ?>
          <a href="watch_video.php?id=<?= h($v['id']) ?>" class="video-list-item <?= $v['id'] === $id ? 'current' : '' ?>">
            <span class="num"><?= $v['id'] === $id ? '&#9654;' : ($i + 1) ?></span>
            <span class="video-list-title"><?= h($v['title']) ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
