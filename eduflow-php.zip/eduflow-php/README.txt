==================================================
  EduFlow LMS - Namecheap Installation Guide
==================================================

REQUIREMENTS
------------
- PHP 7.4+ (PHP 8.x recommended)
- MySQL 5.7+
- mod_rewrite enabled (optional, not required)

INSTALLATION STEPS
------------------

1. UPLOAD FILES
   Upload all files in this folder to your Namecheap
   public_html directory (or a subdirectory).

2. CREATE DATABASE
   - Log in to Namecheap cPanel
   - Go to "MySQL Databases"
   - Create a new database (e.g. yourusername_eduflow)
   - Create a database user and set a password
   - Add the user to the database (All Privileges)

3. IMPORT SQL SCHEMA
   - Go to phpMyAdmin in cPanel
   - Select your new database
   - Click "Import" tab
   - Choose the file: database.sql
   - Click "Go"

4. EDIT CONFIG.PHP
   Open config.php and update:

   define('DB_HOST', 'localhost');
   define('DB_NAME', 'yourusername_eduflow');
   define('DB_USER', 'yourusername_dbuser');
   define('DB_PASS', 'your_db_password');
   define('SITE_URL', 'https://yourdomain.com');

   If installed in a subfolder (e.g. /eduflow):
   define('SITE_URL', 'https://yourdomain.com/eduflow');

5. SET PERMISSIONS
   The uploads/ directory needs to be writable:
   chmod 755 uploads/
   chmod 755 uploads/thumbnails/
   chmod 755 uploads/tutors/
   (Do this via cPanel File Manager or FTP)

6. TEST THE SITE
   Visit your domain in a browser.

   Admin login: admin@eduflow.art / admin175
   (Register a student account via the Sign Up button)

TROUBLESHOOTING
---------------
- Blank page: Enable PHP errors temporarily by adding
  ini_set('display_errors', 1); at the top of config.php

- Database error: Double-check DB_NAME, DB_USER, DB_PASS
  in config.php match your cPanel MySQL settings

- Images not uploading: Check uploads/ folder permissions
  (must be 755 or 777)

- SITE_URL wrong: If links are broken, ensure SITE_URL
  exactly matches your domain without trailing slash

SUPPORT
-------
Email: support@eduflow.art

==================================================
