<?php require_once 'config.php';
requireStudent();
$pageTitle = 'My Bookmarks';

$db = getDB();
$stmt = $db->prepare("SELECT p.*, t.name AS tutor_name, t.profession AS tutor_profession,
    (SELECT COUNT(*) FROM content c WHERE c.playlist_id = p.id AND c.status='active') AS video_count
    FROM bookmarks b
    JOIN playlists p ON p.id = b.playlist_id
    JOIN tutors t ON t.id = p.tutor_id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$bookmarks = $stmt->fetchAll();
include 'includes/header.php'; ?>

<section class="page-header">
  <div class="container">
    <h1>My Bookmarks</h1>
    <p>Your saved courses — pick up where you left off.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <?php if ($bookmarks): ?>
      <p class="text-muted text-small mb-2"><?= count($bookmarks) ?> saved course<?= count($bookmarks) !== 1 ? 's' : '' ?></p>
      <div class="courses-grid">
        <?php foreach ($bookmarks as $pl): ?>
          <div class="course-card" style="position:relative">
            <a href="course_detail.php?id=<?= h($pl['id']) ?>" style="display:block">
              <div class="course-thumb">
                <img src="<?= getThumbnailUrl($pl['thumbnail'], $pl['title']) ?>" alt="<?= h($pl['title']) ?>" loading="lazy">
                <span class="course-category"><?= h($pl['category']) ?></span>
              </div>
              <div class="course-body">
                <div class="course-title"><?= h($pl['title']) ?></div>
                <div class="course-meta">
                  <span class="course-tutor">&#127891; <?= h($pl['tutor_name']) ?></span>
                  <span class="course-videos">&#127909; <?= (int)$pl['video_count'] ?> videos</span>
                </div>
              </div>
            </a>
            <div style="padding:.75rem 1.1rem .9rem;border-top:1px solid var(--border)">
              <form method="POST" action="actions/bookmark.php" style="display:inline">
                <input type="hidden" name="playlist_id" value="<?= h($pl['id']) ?>">
                <input type="hidden" name="redirect" value="bookmarks.php">
                <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--danger)">&#128473; Remove</button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state">
        <div class="icon">&#128278;</div>
        <h3>No bookmarks yet</h3>
        <p>Browse courses and bookmark the ones you want to save for later.</p>
        <a href="courses.php" class="btn btn-primary" style="margin-top:1rem">Browse Courses</a>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
